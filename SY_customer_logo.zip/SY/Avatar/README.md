# Avatar-M2
Profile Avatar Module for Magento 2.x