<?php
/**
 * Profile Avatar
 * 
 * @author Slava Yurthev
 */
\Magento\Framework\Component\ComponentRegistrar::register(
	\Magento\Framework\Component\ComponentRegistrar::MODULE,
	'SY_Avatar',
	__DIR__
);