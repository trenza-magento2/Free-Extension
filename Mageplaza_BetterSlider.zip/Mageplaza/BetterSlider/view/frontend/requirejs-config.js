var config = {
    // map: {
    //     '*': {
    //         'owlcarousel': 'Mageplaza_BetterSlider/js/owl.carousel',
    //     },
    // },
    // paths: {
    //     'owlcarousel': 'Mageplaza_BetterSlider/js/owl.carousel',
    // },
    // shim: {
    //     'owlcarousel': {
    //         deps: ['jquery']
    //     }
    // }
};