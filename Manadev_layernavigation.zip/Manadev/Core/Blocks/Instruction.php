<?php
/**
 * @copyright   Copyright (c) http://www.manadev.com
 * @license     http://www.manadev.com/license  Proprietary License
 */

namespace Manadev\Core\Blocks;

use Magento\Framework\View\Element\AbstractBlock;
use Magento\Framework\View\Element\Context;
use Manadev\Core\Features;

class Instruction extends AbstractBlock
{
    public function remove($blockToBeRemoved, $removedByFeature) {
    }
}