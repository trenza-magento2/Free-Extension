/**
 * @copyright   Copyright (c) http://www.manadev.com
 * @license     http://www.manadev.com/license  Proprietary License
 */

var config = {
    map: {
        '*': {
            hideShowElementCheckbox: 'Manadev_Core/js/hideShowElementCheckbox',
            hideShowElementSelect: 'Manadev_Core/js/hideShowElementSelect',
            manadevField: 'Manadev_Core/js/field'
        }
    }
};
